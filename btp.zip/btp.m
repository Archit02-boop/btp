A = [[0 1 0 0];[0 -0.1818 2.6730 0];[0 0 0 1];[0 -0.4545 -31.1800 0]];
B = [0;1.818;0;4.545];
C = [1 0 0 0];
delta  = 0.001;
tspan = 0:delta:6-delta;
u = sin(tspan);
% Define initial condition for x 
x0 = [0; 0; 0; 0];

% Define the system of ODEs
odefun = @(t, x) A * x + B * sin(t);

% Solve using ode45
[t, x] = ode45(odefun, tspan, x0);
x = x';
y = C*x;
y_train  = y(1:2000);
y_test = y(2001:end);
r = 4;
q = 4;
p = 2000 - q;
% Predefine Hankel matrix dimensions
H = zeros(q, p);
for i = 1:p
    for j = 1:q
        H(j, i) = y_train(i + j - 1);
    end
end
%SVD
[U,S,V] = svd(H);
Ur = U(:,1:r);
Vr = V(:,1:r);
Sr = S(1:r,1:r);
Vr_T = Vr';
Hr = Ur*Sr*Vr';
disp(Ur*Sr);
error = norm(H - Hr,'fro');
% Compute time derivatives of Vr
Vr_dot = zeros(size(Vr));
for i = 2:(size(Vr, 1)-1)
    Vr_dot(i, :) = (Vr(i+1, :) - Vr(i-1, :)) / (2 * delta);  % Central difference
end

% Forward and backward difference for boundaries
Vr_dot(1, :) = (Vr(2, :) - Vr(1, :)) / delta;
Vr_dot(end, :) = (Vr(end, :) - Vr(end-1, :)) / delta;
ur = sin(t(1:p)); 
% Construct Theta(Vr)
Theta_Vr = [Vr, ur]; 

numObservations = 1996;
numPredictors = 5;
lambda = 0.001;
%%
% L1-regularized LAD regression using CVX (vectorized, with explicit L1 norm)
cvx_begin
    variable xi(4, 5);
    minimize(norm(Vr_dot - Theta_Vr*xi',1))
cvx_end

% Display the results
disp('Estimated coefficients (CVX):');
disp(xi);
%%
A_hat = xi(1:4,1:4);
B_hat = xi(1:4,5);
C_hat = Ur*Sr;
C_hat = C_hat(1,:);
e_val = eig(A_hat);
e_true = eig(A);
disp(e_val);
disp(e_true);








